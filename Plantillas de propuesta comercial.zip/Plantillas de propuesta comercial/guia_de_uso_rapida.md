# Guía Rápida: Sistema de Propuestas Comerciales con IA

¡Bienvenido al kit de propuestas comerciales automatizadas! Esta guía te enseña cómo pasar de una nota rápida de una llamada con un cliente a un dossier de venta profesional en menos de 3 minutos.

---

## 🚀 ¿Qué incluye este paquete?
1. **El Prompt Maestro (`prompt_maestro.txt`):** El archivo de instrucciones para alimentar a Claude o ChatGPT.
2. **La Estructura del Dossier:** El orden psicológico exacto que convierte a un cliente indeciso en un contrato firmado.
3. **El Flujo de n8n (Opcional):** Preparado para automatizar la inserción en Google Docs / PDF.

---

## 📝 Paso a Paso para Generar tu Propuesta Manualmente (o con IA)

### 1. Recopila los datos clave de la llamada
No necesitas escribir un testamento. Anota en 2 minutos lo que te dijo el cliente:
- Su nombre y empresa.
- Su **problema principal** (usa sus propias palabras: *"No tenemos tiempo para revisar las campañas y los clientes se quejan"*).
- El objetivo que busca.

### 2. Introduce los datos en el Prompt
Abre Claude o ChatGPT, pega el **System Prompt** y el **User Prompt** rellenando las variables entre llaves `{{ }}` con la información del cliente.

### 3. Copia el JSON resultante
La IA te devolverá un objeto JSON estructurado con los textos perfectos para cada sección:
- Resumen ejecutivo de impacto.
- Diagnóstico clínico del problema.
- Solución por fases y opciones de inversión (Esencial / Recomendado / Premium).

### 4. Vuelca los textos en tu Plantilla Visual
Copia los textos generados en tu plantilla de Canva, Google Docs o Notion. Exporta como PDF y envíaselo al cliente con una validez máxima de 7 a 14 días para generar urgencia.

---
💡 **Consejo Pro:** Nunca envíes la propuesta el mismo día de la llamada si puedes evitarlo. Tómate unas horas para que la IA procese el diagnóstico y tú puedas revisarlo: la personalización extrema es lo que justifica tarifas de más de 1.000 € por proyecto.